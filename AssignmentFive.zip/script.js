/*
* Title: Rock, Paper, Scissors Wonderland.
* Summary: Enables the user to play 'Rock, Paper, Scissors' either with the computer or against another player. 
* Program Element List: HTML: Feedback Form, Email & Call Us Features, Menu Bar, Table, Explanatory Scoreboard. JavaScript: Functions, Comparison Operators, document.getElementsByClassName, Switch, Return, Audio, If ... Else Statement, Let variable declaration, console.log(), Parameters, Console Clear, Alert, Prompt, While True Loop, .toLowerCase() Method, document.getElementById to modify properties such as display or innerText.
*/

//print characters one by one using a loop, then print page with wellness results and score with their name., etc.



//Function Declarations





/* 
summary: This function shows the Main Menu for the user.
@parms: None.
@return: None.
*/
function mainmenu2 () {
  score = 0;
  score2 = 0;
  
  document.getElementById("buttoni").style.display = "inline"; // Displays the main menu button to the user.
  document.getElementById("buttoner").style.display = "inline";
  document.getElementById("hidebutton").style.display = "inline";
  document.getElementById("bigger").style.display = "none";
  document.getElementById("whichone").style.display = "none";
  document.getElementById("whichone2").style.display = "none";
  document.getElementById("playerlogs").style.display = "none";
  document.getElementById("scoreboard").style.display = "none";
  document.getElementById("playagain").style.display = "none";
  document.getElementById("mainmenu2").style.display = "none";
  document.getElementById("mainmenu").style.display = "none";
  document.getElementById("showconsole").style.display = "none";
  document.getElementById("starting").style.display = "none";
  
}

			function generatePDF() {
        
        document.getElementById("download-button").style.display = "none";

          
        for (let lettertype = 0; lettertype < 100; lettertype++) {
          let hello = document.getElementById("nicecool").innerHTML;
        let current = hello.charAt(lettertype);
       
         current.style.display = "inline";
          
          
        }
            
				// Choose the element that your content will be rendered to.
				const element = document.getElementById('invoice');
    
				// Choose the element and save the PDF for your user.
				html2pdf().from(element).save();
   
     document.getElementById('downloadedreport').style.display = "block";
			}

	


function runprogram() {

  generatePDF();



  
}


/*
summary: Switches between the website's 'one player' and 'two player' modes.
@parms: none
@return: none
*/
function modeToggle() {
    document.getElementById("scoreboard").style.display = "none";
    document.getElementById("playerlogs").style.display = "none";
    document.getElementById("playagain").style.display = "none";
    document.getElementById("hidebutton").style.display = "none";
    document.getElementById("bigger").style.display = "inline"; // Alters the display of the HTML element(s) with the ID of 'bigger'.
    document.getElementById("mainmenu").style.display = "inline";
} // End of the modeToggle() function.





/*
summary: Asks the user to confirm that they would like to return to the main menu in order to toggle between modes.
@parms: none
@return: none
*/
function mainmenu() {
    let again = 0 ; 
    again = prompt(`Would you like to go back to the main menu? If you do so, any score which may exist on the scoreboard will be reset. If you would still like to do so, please type in 'yes.'`);
   
    if (again == "yes" || again == "Y" || again == "y" || again == "Yes" || again == "YE" || again == "ye" || again == "YES" || again == "Ye")  {
        document.getElementById("helloname").innerText = 0;
        document.getElementById("hellocomputer").innerText = 0;
    		scorecomputer = 0;
        scoreplayer = 0; // Sets the value of the 'scoreplayer' variable to 0.
        document.getElementById("hidebutton").style.display = "inline";
        document.getElementById("bigger").style.display = "none";
        document.getElementById("playerlogs").style.display = "none";
        document.getElementById("scoreboard").style.display = "none";
        document.getElementById("playagain").style.display = "none";
        document.getElementById("mainmenu").style.display = "none";
    	  } else if (again == '') {
              mainmenu();
        } else {
    			   console.log("The user has chosen to continue to browse the remainder of the website.");
    } // End of the if ... else statement which controls what happens based on the user's response to an alert.
} // End of the mainmenu() function.





/*
Summary: Compares both user input and computer generated value, then determines a winner.
@parms: userPicker, computerChoice
@return: Returns either "You lose!", "You win!", or "Tie!"
*/
function determineWinner(userPicker, computerChoice) {
    let userPick = userPicker;
    let computerChoices = computerChoice;
    
    if (userPick == computerChoices) {
        return "Tie!";
        } else if (userPick == "rock") {
            if (computerChoices == "paper") {
                return "You lose!"; // The return if the user selects rock and the computer selects paper.
                } else {
                    return "You win!";
            } // End of what would occur if the computer selcted paper and the user selected anything other than rock.
        } else if (userPick == "paper") {
            if (computerChoices == "scissors") {
                return "You lose!";
                } else {
                      return "You win!";
            } // End of what would occur if the computer selcted scissors and the user selected anything other than paper.
        }  else if (userPick == "scissors") {
            if (computerChoices == "rock") {
                return "You lose!";
                } else {
                      return "You win!";
            } // End of what would occur if the computer selcted rock and the user selected anything other than scissors.
        } else {
        console.log('There has been an error.');
    } // End of what would occur if the user and the computer did not have selections that resulted in a definitive return.
} // END of the determineWinner() function.




/*
summary: This function will generate a random number between 0 and 3. There is a switch which has 3 cases that will return the computer's choices as either rock, paper, or scissor.
@parms: None.
@return: Returns rock, paper, or scissor.
*/
function getComputerChoice() {
  let computerChoice = Math.floor(Math.random() * 3); // Primary Calculation.
  
  switch(computerChoice) { 
    case(0):
        return 'rock'; // Returns rock from the function based on the random number.
        break;
    case(1):
        return 'paper';
        break;
    default:
        return 'scissors';
        break;
  } // End of determing whether the computer will choose rock, paper, or scissors.
} // End of the getComputerChoice() function.






/*
summary: This function will print out the results of the game and reiterate the user's input. this function will call upon all the other functions and bring them into one program. Only shows the results of the game until the user picks a weapon.
@parms: userPick, 
@return: none
*/
function playGame(userPicking) {
    let userPicker = userPicking;
    let computerChoice = getComputerChoice();
  
    document.getElementsByClassName("buttonhover1").width = 150; 
    document.getElementsByClassName("buttonhover2").width = 150; 
    document.getElementsByClassName("buttonhover3").width = 150; 
    document.getElementsByClassName("buttonhover1").height = 200; 
    document.getElementsByClassName("buttonhover2").height = 200; 
    document.getElementsByClassName("buttonhover3").height = 200; 
    document.getElementById("bigger").style.opacity = 0.5; 
    document.getElementById("mainmenu").style.display = "none";
    
    console.clear();
    console.log(userPicker);
    console.log(computerChoice);
  
    document.getElementById("reiterateinput").innerText = ("You selected " + userPicker + "!"); //Re-iterate Input
    document.getElementById("computerinput").innerText = ("The computer chose " + computerChoice + "!");
    document.getElementById("reiterateoutput").innerText = (determineWinner(userPicker, computerChoice)); //Output
    
    setTimeout(newfunctioner, 1000);
} // END of playGame function



/*
summary: After playing a round, the user is prompted to return to the main menu.
@parms: none
@return: none
*/
function newfunctioner() {
    document.getElementById("playagain").style.display = "inline";
    document.getElementById("bigger").style.display = "none";
    document.getElementById("showconsole").style.display = "none";
    document.getElementById("bigger").style.opacity = 1;
    document.getElementById("mainmenu").style.display = "block";
    document.getElementById("playerlogs").style.display = "inline"; // Reiterate input and state output
    document.getElementById("scoreboard").style.display = "inline";
    document.getElementById("whichone").style.display = "inline";
    document.getElementById("whichone2").style.display = "inline";
    document.getElementById("whichone").innerText = "Computer";
    document.getElementById("whichone2").innerText = "You"; // Changes the text of the HTML element with the ID of 'whichone2'.
    
    if (document.getElementById("reiterateoutput").innerText == "You win!") {
        scoreplayer += 1;
        scorecomputer += 0;
        document.getElementById("helloname").innerText = scoreplayer;
        document.getElementById("hellocomputer").innerText = scorecomputer;
        } else if (document.getElementById("reiterateoutput").innerText == "Tie!") {
            scoreplayer += 0;
            scorecomputer += 0;
            document.getElementById("helloname").innerText = scoreplayer;
            document.getElementById("hellocomputer").innerText = scorecomputer;
        } else if (document.getElementById("reiterateoutput").innerText == "You lose!") {
            scoreplayer += 0;
            scorecomputer += 1;
            document.getElementById("helloname").innerText = scoreplayer;
            document.getElementById("hellocomputer").innerText = scorecomputer;
        } else {
              console.log('error');
    } // End of what would happen to the scoreboard based on the user's results.
} // End of the newfunctioner() function.





/*
summary: This function will allow player1 to make a choice between rock, paper, scissor. It will ensure the user is inputting the right values.
@parms: None.
@return: player1

function player() {
    let player24 = prompt(`Player 1, please enter 'rock', 'paper', or 'scissors'.`);
    player24.toLowerCase; // Changes the player24 variable to lowercase.
  
    while (player24 !== "scissors" && player24 !== "rock" && player24 !== "paper" && player24 !== "bomb") {
          player24 = prompt(`Please enter either 'rock', 'paper', or 'scissors'.`);
          player24.toLowerCase;
    } // The end of the while loop which asks the suer for the correct input.

    return player24;
} // End of the player() function.
*/





/*
summary: This function will allow Player 2 to make a choice between rock, paper, scissor. It will ensure the user is inputting the right values.
@parms: None.
@return: None.

function playertwo() {    
    let player25 = prompt(`Player 2, please enter 'rock', 'paper', or 'scissors'.`);
    player25.toLowerCase; // Alters the variable's characters to lowercase.
  
    while (player25 !== "scissors" && player25 !== "rock" && player25 !== "paper" && player25 !== "bomb") {
        player25 = prompt(`Please enter either 'rock', 'paper', or 'scissors'.`);
        player25.toLowerCase;
    }

    return player25; // Returns the value of the player25 variable when the function is called.
} // End of the playertwo() function.
*/





/* 
summary: This function will determine if player1 or player2 wins. After it determines the winner it will return a message which specifies won. It will also increase the score of the players based on their number of wins. 
@parms: None.
@return: None.

function determinewin() {
    let message; // Creates the 'message' variable.
    let p1 = player();
    let p2 = playertwo();
    if (p1 === p2) {
        message = "You have tied!";
        } else if (p1 === "scissor" && p2 === "rock") {
               score2++;
               message = "Player 2 has won!";
        } else if (p1 === "paper" && p2 === "scissor") {
              score2++;
              message = "Player 2 has won!";
        } else if (p1 === "rock" && p2 === "paper" )  {
              score2++;
              message =  "Player 2 has won!" ;
        } else if (p1 === 'rock' && p2 === "scissor"){
              score++;
              message = "Player 1 has won!";
        } else if (p1 === 'scissor' && p2 ==='paper') {
              score++;
              message = "Player 1 has won!";
        } else if (p1 === "paper" && p2 === "rock") {
              score++;
              message = "Player 1 has won!"; 
        } else if (p1 === "bomb") {
              score = score + 100;
              message = "Player 1 has DESTROYED Player 2!";
        } else if (p2 === "bomb") {
             score2 = score2 + 100;
             message = "Player 2 has DESTROYED Player 1!";
    } // End of the if ... else statement which alters the score and determines the result.

    return message;
  
} // End of determinewin() function.
*/







/* 
summary: This is the main function for the twoplayer version of the game. It will excute other functions, print the score, and share results alongside an alert regarding who won the game.
@parms: None.
@return: None.
*/
function playgame2() {
    donot = 0; // Sets the variable 'donot' to 0.
  
    document.getElementById("buttoner").style.display = "none";
    document.getElementById("whichone").style.display = "none";
    document.getElementById("whichone2").style.display = "none";
    document.getElementById("scoreboard").style.display = "none";
    document.getElementById("buttoner").style.display = "none";
    document.getElementById("buttoni").style.display = "none";
    document.getElementById("showconsole").style.display = "inline";
    document.getElementById("mainmenu2").style.display = "inline";
  
    setTimeout(anotherfunction, 1000);
  
    song2();
} // End of the function which deter




/* 
summary: This function primarily alters the value of HTML elements and displays the scoreboard and the 'showconsole' message for the user.
@parms: None.
@return: None.
*/
function playgame21() {
    donot = 0;
    
    document.getElementById("buttoner").style.display = "none";
    document.getElementById("whichone").style.display = "inline";
    document.getElementById("whichone2").style.display = "inline";
    document.getElementById("scoreboard").style.display = "inline"; // Shows the scoreboard for the user.
    document.getElementById("buttoner").style.display = "none";
    document.getElementById("buttoni").style.display = "none";
    document.getElementById("showconsole").style.display = "inline";
    document.getElementById("mainmenu2").style.display = "inline";
    
    setTimeout(anotherfunction, 1000);
  
    song2();
} // End of the playame21() function.





/* 
summary: Asks the two users to input their preferred values for the game, and displays the scoreboard.
@parms: None.
@return: None.

function anotherfunction () {
    if (document.getElementById("mainmenu2").style.display === "inline") {
        document.getElementById("starting").style.display = "inline"; // Shows the HTML element(s) with the ID of starting.
        let re = determinewin();
        alert(re);
        document.getElementById("scoreboard").style.display = "inline";
        document.getElementById("showconsole").style.display = "inline";
        document.getElementById("whichone").style.display = "inline";
        document.getElementById("whichone2").style.display = "inline";
        document.getElementById("helloname").innerText = score;
        document.getElementById("hellocomputer").innerText = score2;
        document.getElementById("whichone2").innerText = "Player 1";
        document.getElementById("whichone").innerText = "Player 2";   
        } else if (document.getElementById("mainmenu2").style.display === "none") {
              console.log('none');
        } else {
              console.log('none');
    } // End of the if ... else statement which displays the scoreboard and obtains the user's results.
} // End of the playgame2() function.

*/



/*
summary: Replaces HTML elements' text when the "Share Your Answers!" button is pressed, in order to thank the user for their feedback.
@parms: none
@return: none
*/
function heythere() { // Thanks the user for utilizing the program.
    let theText = 0;
    let theEmail = 0; // Sets the value of the variable 'theEmail'.
    theText = document.getElementById("yourthoughts").innerText;
    theEmail = document.getElementById("emailplease").innerText;

    if (typeof theEmail == 'string' && typeof theText == 'string') {
        document.getElementById("displayer").style.display = 'none';
        document.getElementById("imageGo").style.display = 'none';
        document.getElementById("sharemore").innerText = `You're Appreciated!`;
        document.getElementById("detail").innerText = 'Thank you for submitting our feedback form! We hope you enjoy the remainder of your day!';
        } else if (typeof theEmail == 'null' && typeof theText == 'string') { 
            document.getElementById("fillout").innerText = "*Please fill this out!*";
        } else {
            console.log('user has not entered anything');
    } // End of the if ... else statement which determines whether or not the user has submitted the feedback form.
} // End of they heythere() function.





/* 
summary: This function will play a song upon being called.
@parms: None.
@return: None.
*/
function song() {
    let audio = new Audio('song.mp3');
    audio.play(); // Play the audio.
} // End of song() function.






/* 
summary: This function will also play a song upon being called.
@parms: None.
@return: None.
*/
function song2() {
    let audio = new Audio('song.mp3');
    audio.play(); // Play the audio.
} // End of song2() function.








/*
summary: Opens the navigation bar.
@parms: None.
@return: None.
*/
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";  //Opening the navigation bar.
    document.getElementById("main").style.marginLeft = "250px";  //Moving the content of the website to the right once the navigation bar opens.
} // END of openNav function







/*
summary: Closes the navigation bar.
@parms: None.
@return: None.
*/
function closeNav() {
    document.getElementById("mySidenav").style.width = "0"; //Closing the navigation bar.
    document.getElementById("main").style.marginLeft = "0"; //Moving the content of the website back to its original position once the navigation bar closes.
} // End of the closeNav() function.





// Variable Declarations

let score = 0;
let score2 = 0;
let scoreboard = 0;
let scorecomputer = 0;
let scoreplayer = 0;
let donot = 0;





// Beginning of Program





//Beginning of Main

function cool() {

  reset();
  getuserinput();
  getrecommendedsleep();
  calculateoutput();
  thanks();
  
}

//End of Main





//End of Program



/*


Notes: 
-add music, etc.

Test Code:



*/
