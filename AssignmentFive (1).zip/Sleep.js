/*

  Title: Sleep Debt Calculator
  	
  Program Summary: 
	
  Key Program Elements Utilized: Variables, use of document.getElementById, a variety of Data Types, If ... Else If ... Else statements, Functions, Arithmetic Operators, setAttribute property, change the properties of min and max of HTML elements with JavaScript,  when it comes to JavaScript. HTML/CSS syntax was utilized in order to create an excellent web experience.


*/






// Functions Declarations






/*

 * Summary: This function hides the button based on its ID, which is "myButton." It also makes HTMl elements with the  ID of "first" become visible.
 * Parameters: None
 * Return: None; instead, elements which have the ID of "myButton" and "first" obtain an altered value of visibility.

 */


function getSleepHours(day, hours) {
  
  switch(day){
    case 'monday':
      console.log(day, ' : ',hours);
      break;
      
    case 'tuesday':
      console.log(day, ' : ',hours);
      break; 
      
    case 'wednesday':
      console.log(day, ' : ',hours);
      break; 
      
    case 'thrusday':
      console.log(day, ' : ',hours);
      break;
      
    case 'friday':
      console.log(day, ' : ',hours);
      break; 
      
    case 'saturday':
      console.log(day, ' : ',hours);
      break; 
      
    case 'sunday':
      console.log(day, ' : ',hours);
      break;
    
  }
  return Number(hours);
} //end of getSleepHours function






/*

 * Summary: This function hides the button based on its ID, which is "myButton." It also makes HTMl elements with the  ID of "first" become visible.
 * Parameters: None
 * Return: None; instead, elements which have the ID of "myButton" and "first" obtain an altered value of visibility.

 */

function getActualSleepHours() {
  var week = document.getElementsByClassName('dayoftheweek');
  var result = 0; 

  
  for (i=0; i<7; i++) {
    result += getSleepHours(week[i].dataset.name, week[i].value);
  }
  return result; 
} //end of getActualSleepHours function






/*

 * Summary: This function hides the button based on its ID, which is "myButton." It also makes HTMl elements with the  ID of "first" become visible.
 * Parameters: None
 * Return: None; instead, elements which have the ID of "myButton" and "first" obtain an altered value of visibility.

 */

function getName() {
  userName = prompt('What is your name?');
}

function getIdealSleepHours() {
  age = prompt('What is your age? (range is 1 ~ 65+)');

  if (age >= 1 && age <= 2) {
    idealHours = 84;

  } else if (age >= 3 && age <= 5) {
    idealHours = 70; 
    
  } else if (age >= 6 && age <= 12) {
    idealHours = 63;
    
  } else if (age >= 13 && age <= 18) {
    idealHours = 56; 
    
  } else if (age >= 18 && age <= 120) {
    idealHours = 49;
  }
getName();
  return idealHours;
} //end of getIdealSleepHours function






/*

 * Summary: This function hides the button based on its ID, which is "myButton." It also makes HTMl elements with the  ID of "first" become visible.
 * Parameters: None
 * Return: None; instead, elements which have the ID of "myButton" and "first" obtain an altered value of visibility.

 */

function calculateSleepDebt() {
  actualSleepHours = getActualSleepHours();
  idealSleepHours = getIdealSleepHours();

  if (actualSleepHours == idealSleepHours) {
    console.log(`${userName} got the perfect amount of sleep.`);
  }
  else if (actualSleepHours > idealSleepHours) {
    console.log(`${userName} got more sleep than needed.`);
  }
  else {
    console.log(`${userName} should get more sleep.`)
  }
} //end of calculateSleepDebt function

/* calculating the score 
if user < sleep  decrase 50% of the mark 
if user > sleep decrase 20% of the mark 
if user = sleep increase 30% of the mark 

adding all personal wellness score at the end 
*/
//Beginning Of Program

document.getElementById('confirm').addEventListener('click', calculateSleepDebt);






// Variable Declarations - The variables used throughout the program are declared below.

var actualSleepHours; 

var idealSleepHours; 

var userName = '';

var idealHours;

var age; 





//Beginning of Main





//End of Main







// End of Program





/* NOTES:





    Test Code Can Be Found Below:
      /*var monday = document.getElementById(dayweek[0]).value;
    var tuesday = document.getElementById('tueshours').value;
    var wednesday = document.getElementById('wedhours').value;
    var thrusday = document.getElementById('thurshours').value;
    var friday = document.getElementById('frihours').value;
    var saturday = document.getElementById('sathours').value;
    var sunday = document.getElementById('sunhours').value; 
    */
    
/*document.getElementById('confirm').addEventListener('click', function() {
   var dayweek = ['monhours', 'tueshours', 'wedhours', 'thurshours', 'frihours', 'sathours', 'sunhours'];
  //var dayhours = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  var dayhours = [];

    for(i=0; i<7; i++) {
      dayhours[i] = document.getElementById(dayweek[0]).value;
    }

    getActualSleepHours();
});*/
  
  
